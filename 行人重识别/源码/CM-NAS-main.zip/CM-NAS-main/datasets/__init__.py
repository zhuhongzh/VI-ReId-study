from .sysu_dataset import SYSUData, process_query_sysu, process_gallery_sysu
from .regdb_dataset import RegDBData, process_test_regdb
from .test_dataset import TestData