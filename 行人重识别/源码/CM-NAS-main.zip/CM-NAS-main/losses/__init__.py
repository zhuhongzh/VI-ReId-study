from .triplet_loss import TripletLoss
from .ce_with_ls import CrossEntropyLabelSmooth
from .sp import SP
from .cmmd import CMMD